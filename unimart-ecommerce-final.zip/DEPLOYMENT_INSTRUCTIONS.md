# UniMart E-commerce Deployment Instructions

This document provides instructions for deploying the UniMart E-commerce platform to various hosting platforms.

## Prerequisites

- Node.js v18 or higher
- PostgreSQL database
- Git

## Environment Variables

You will need to set up the following environment variables on your hosting platform:

```
DATABASE_URL=postgresql://username:password@host:port/database
PGHOST=your_postgres_host
PGUSER=your_postgres_user
PGPASSWORD=your_postgres_password
PGDATABASE=your_postgres_database
PGPORT=your_postgres_port
SESSION_SECRET=a_random_secret_key_for_sessions
```

For Stripe integration (optional):
```
STRIPE_SECRET_KEY=your_stripe_secret_key
VITE_STRIPE_PUBLIC_KEY=your_stripe_public_key
```

## GitHub Deployment

1. Create a new repository on GitHub
2. Initialize git in your local project folder:
   ```
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/your-username/unimart.git
   git push -u origin main
   ```

## Render Deployment

1. Sign up for a Render account at https://render.com
2. Connect your GitHub repository
3. Create a new Web Service
4. Set the following:
   - Name: unimart
   - Environment: Node
   - Build Command: `npm install && npm run build`
   - Start Command: `npm run start`
5. Add all required environment variables in the "Environment" section
6. Click "Create Web Service"

## Database Migration

After deploying, you need to run the database migrations:

```
npm run db:push
```

This will create all necessary tables in your PostgreSQL database.

## File Structure

- `/client` - Frontend React code
- `/server` - Backend Express API
- `/shared` - Shared types and schemas
- `/migrations` - Database migrations

## Key Features

- Multi-vendor marketplace
- Role-based access (customers, vendors, admins)
- Category-based navigation with Amazon-like organization
- Integrated payment processing
- Delivery tracking
- Advanced analytics dashboard
- Responsive design for all devices

## Support

For support or questions, please create an issue on the GitHub repository.