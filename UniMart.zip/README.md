# UniMart Marketplace App

This is a full-stack marketplace app built with React (frontend) and Node.js/Express (backend).